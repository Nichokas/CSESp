def conversion(text):
    # Tu codigo aqui.

def main():
    # Tu codigo aqui.

# Por favor no modifiques este código, si no la prueba fallara.
if __name__ == "__main__":
    main()